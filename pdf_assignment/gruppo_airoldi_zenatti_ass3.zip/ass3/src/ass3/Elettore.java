package ass3;

import java.util.Arrays;
import java.util.Calendar;

import javax.xml.stream.events.Characters;

public class Elettore {
	
	//ATTRIBUTI
	
	private /*@ spec_public @*/ String nome;
	private /*@ spec_public @*/ String cognome;
	private /*@ spec_public @*/ int giorno;
	private /*@ spec_public @*/ int mese;
	private /*@ spec_public @*/ int anno;
	private /*@ spec_public @*/ String comuneNascita;
	private /*@ spec_public @*/ String nazioneNascita;
	private /*@ spec_public @*/ char sesso;
	private /*@ spec_public @*/ char[] codiceFiscale;
	private /*@ spec_public @*/ boolean haVotato;
	
	//@public invariant nome != null && cognome !=null;
	
	
	//COSTRUTTORI
	
	/*@
	 @ requires sesso == 'M' || sesso == 'F';
	 @ requires (Calendar.getInstance().get(Calendar.YEAR) > anno) ||
	 @ 			(Calendar.getInstance().get(Calendar.YEAR) == anno && Calendar.getInstance().get(Calendar.MONTH) > mese ) ||
	 @			(Calendar.getInstance().get(Calendar.YEAR) == anno && Calendar.getInstance().get(Calendar.MONTH) == mese  && Calendar.getInstance().get(Calendar.DAY_OF_MONTH) >=giorno ) ;
	 @ requires nazioneNascita.equalsIgnoreCase("Italia") ==> comuneNascita != null;
	 @ requires checkCodiceFiscale(nome,cognome,giorno,mese,anno,comuneNascita,nazioneNascita,sesso,codiceFiscaleStr.toCharArray())==true; 
	 @*/
	public Elettore(String nome, String cognome, int giorno, int mese, int anno, String comuneNascita,String nazioneNascita, char sesso, String codiceFiscaleStr) {
		this.nome = nome;
		this.cognome = cognome;
		this.giorno = giorno;
		this.mese = mese;
		this.anno = anno;
		this.comuneNascita = comuneNascita;
		this.nazioneNascita = nazioneNascita;
		this.sesso = sesso;
		this.codiceFiscale = codiceFiscaleStr.toCharArray();
		haVotato= false;
		
	}
	
	
	//MAIN
	public static void main(String[] args) {
		//Elettore e1 = new Elettore("Federico","Zenatti",24,6,2000,"MILANO","ITALIA",'M',"ZNTFRC00H24F205N"); // Corretto
		//System.out.println(e1.toString());
		//e1.esprimi_voto();
		//e1.esprimi_voto(); //non posso perche ho gia votato
		
		//Elettore e2 = new Elettore("Federico","Zenatti",24,6,2000,"MILANO","ITALIA",'M',"ZNTFRC00H24F2S5N"); // Errore CF
		//e2.esprimi_voto();
		//System.out.println(e2.toString());
		
		//Elettore e3 = new Elettore("Federico","Zenatti",24,6,2011,"MILANO","ITALIA",'M',"ZNTFRC00H24F205N"); // Minorenne
		//System.out.println(e3.toString());
		//e3.esprimi_voto();
		
		//Elettore e4 = new Elettore("Federico","Zenatti",32,6,2100,"MILANO","ITALIA",'M',"ZNTFRC00H24F205N"); // Errore Data
		//System.out.println(e4.toString());
		
		//Elettore e5 = new Elettore(null,"Zenatti",32,6,2100,"MILANO","ITALIA",'M',"ZNTFRC00H24F205N"); // Invariante
		
		//Elettore e6 = new Elettore("Federico","Zenatti",24,6,2000,"MILANO","ITALIA",'x',"ZNTFRC00H24F205N"); // Sesso Errato
	}

	//METODI
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public int getGiorno() {
		return giorno;
	}

	public void setGiorno(int giorno) {
		this.giorno = giorno;
	}

	public int getMese() {
		return mese;
	}

	public void setMese(int mese) {
		this.mese = mese;
	}

	public int getAnno() {
		return anno;
	}

	public void setAnno(int anno) {
		this.anno = anno;
	}

	public String getComuneNascita() {
		return comuneNascita;
	}

	public void setComuneNascita(String comuneNascita) {
		this.comuneNascita = comuneNascita;
	}

	public String getNazioneNascita() {
		return nazioneNascita;
	}

	public void setNazioneNascita(String nazioneNascita) {
		this.nazioneNascita = nazioneNascita;
	}

	public char getSesso() {
		return sesso;
	}

	public void setSesso(char sesso) {
		this.sesso = sesso;
	}

	public char[] getCodiceFiscale() {
		return codiceFiscale;
	}

	public void setCodiceFiscale(char[] codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}

	public boolean isHaVotato() {
		return haVotato;
	}

	/*@ requires haVotato == false;
	 @requires (Calendar.getInstance().get(Calendar.YEAR) - anno > 18) ||
	 @         (Calendar.getInstance().get(Calendar.YEAR) - anno == 18) && (Calendar.getInstance().get(Calendar.MONTH) - mese > 0 ) || 
	 @		   (Calendar.getInstance().get(Calendar.YEAR) - anno == 18) && (Calendar.getInstance().get(Calendar.MONTH) - mese == 0 ) && (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) - giorno >0);
	 @*/
	public void esprimi_voto(){
		haVotato = true;
	}
	
	
	@Override
	public String toString() {
		return "Elettore [nome=" + nome + ", cognome=" + cognome + ", giorno=" + giorno + ", mese=" + mese + ", anno="
				+ anno + ", comuneNascita=" + comuneNascita + ", nazioneNascita=" + nazioneNascita + ", sesso=" + sesso
				+ ", codiceFiscale=" + Arrays.toString(codiceFiscale) + ", haVotato=" + haVotato + "]";
	}


	private static /*@ spec_public @*/  boolean checkCodiceFiscale(String nome,String cognome,int giorno,int mese,int anno,String comuneNascita,String nazioneNascita,char sesso,char[] codiceFiscale){
		
		StringBuilder x = new StringBuilder();
		
		x.append(getLettersCognome(cognome.toCharArray()));
		x.append(getLettersNome(nome.toCharArray()));
		
		if (anno%100 > 10){
			x.append(""+ anno%100);
		}else{
			x.append("0");
			x.append(""+ anno%100);
		}
		
		if(getMeseLetter(mese)=='K'){
			return false;
		}

		x.append(getMeseLetter(mese));
		
		if(sesso =='F'){
			x.append(""+giorno+40);
		}else{
			x.append(""+giorno);
		}
	
		if(!nazioneNascita.equalsIgnoreCase("ITALIA")){
			x.append("Z");
		}else{
			x.append("F");
		}
		
		if(!x.toString().equalsIgnoreCase(new String(codiceFiscale).substring(0, 12))){
			return false;
		}
		
		//System.out.println(new String(codiceFiscale).substring(12));
		
		return Character.isDigit(codiceFiscale[12]) && Character.isDigit(codiceFiscale[13]) && Character.isDigit(codiceFiscale[14]) && Character.isLetter(codiceFiscale[15]);
	}
	
	
	private static char getMeseLetter(int mese){
		char m;
		switch (mese) {
			case 1:
				m= 'A';
				break;
			case 2:
				m= 'B';
				break;
			case 3:
				m= 'C';
				break;
			case 4:
				m= 'D';
				break;
			case 5:
				m= 'E';
				break;
			case 6:
				m= 'H';
				break;
			case 7:
				m= 'L';
				break;
			case 8:
				m= 'M';
				break;
			case 9:
				m= 'P';
				break;
			case 10:
				m= 'R';
				break;
			case 11:
				m= 'S';
				break;
			case 12:
				m= 'T';
				break;	
			default:
				m='K'; //Carattere errore
				break;
		}
		
		return m;
	}
	private static char[] getLettersCognome(char[] cognome){
		char [] lettersCognome = new char[3];
		if (cognome.length <=3){ //cognome con  3 lettere o meno
			int idx = 0;
			for(int i = 0; i< cognome.length;i++){
				lettersCognome[idx] =cognome[i];
				idx ++;
			}
			for (int i = idx;i<3;i++){
				lettersCognome[i]='X';
			}
			return lettersCognome;
		}else{
			if(countConsonante(cognome) >=3){
				int count = 0;
				for (int i = 0; i< cognome.length && count <3;i++){
					if(isConsonante(cognome[i])){
						lettersCognome[count]=cognome[i];
						count ++;
					}
					
				}
				
			}else{
				
				int c = countConsonante(cognome);
				int count =0;
				for (int i = 0; i< cognome.length && count <c;i++){
					if(isConsonante(cognome[i])){
						lettersCognome[count]=cognome[i];
						count ++;
					}
				
				}
				
				for(int i = 0; i<cognome.length && count <3;i++){
					if(!isConsonante(cognome[i])){
						lettersCognome[count] = cognome[i];
						count++;
					}
					
				}
				
			}

	
		return lettersCognome;
			
		}
	}
	
	private static char[] getLettersNome(char[] nome){
		char[] lettersNome = new char[3];
		if (nome.length <=3){ //nome con  3 lettere o meno
			
			int idx = 0;
			for(int i = 0; i< nome.length;i++){
				lettersNome[idx] =nome[i];
				idx ++;
			}
			for (int i = idx;i<3;i++){
				lettersNome[i]='X';
			}
		
		}else{
			
			if(countConsonante(nome) ==3){
				
				int count = 0;
				for (int i = 0; i< nome.length && count <3;i++){
					if(isConsonante(nome[i])){
						lettersNome[count]=nome[i];
						count ++;
					}
					
				}
				
				
			}else if(countConsonante(nome) <3){
				
				int c = countConsonante(nome);
				int count =0;
				for (int i = 0; i< nome.length && count <c;i++){
					if(isConsonante(nome[i])){
						
							lettersNome[count]=nome[i];
							count ++;
					}
				
				}
				
				for(int i = 0; i<nome.length && count <3;i++){
					if(!isConsonante(nome[i])){
						lettersNome[count] = nome[i];
						count++;
					}
					
				}
				
				
				
			}else{
				
				int count =0;
				int j =0 ;
				for (int i = 0; i< nome.length && count <3;i++){
					if(isConsonante(nome[i])){
						if(j != 1){
							lettersNome[count]=nome[i];
							count ++;
						}
						j++;
							
					}
				
				}
			}
			
		}
		return lettersNome;
	}
	
	private static boolean isConsonante(char l){	
		return l!= 'A' && l!= 'E' && l!= 'I' && l!= 'O' && l!= 'U'  ;
	}
	private static int countConsonante(char[] cognome){
		int c = 0;
		for(int i = 0; i<cognome.length;i++){
			if(isConsonante(cognome[i])){
				c++;
			}
		}
		return c ;
	}
		
		
		
	

	

}
