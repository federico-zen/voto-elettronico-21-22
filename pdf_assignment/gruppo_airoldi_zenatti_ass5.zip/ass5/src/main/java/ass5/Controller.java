package ass5;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

public class Controller {

	@FXML
	private Label infolabel;
	
    @FXML
    private Button loginbtn;

    @FXML
    private PasswordField psw;

    @FXML
    private TextField user;

    @FXML
    void login(ActionEvent event) {
    	UtenteDAOImpl utenteDAO= (UtenteDAOImpl) DAOFactory.getUserDAO();
    	
    	Utente tmp = utenteDAO.get(user.getText(), psw.getText());
    	if(tmp == null) {
    		infolabel.setTextFill(Color.RED);
    		infolabel.setText("Username o Password Errati ! ");
    	}else {
    		infolabel.setTextFill(Color.GREEN);
    		infolabel.setText("Benvenuto " + tmp.getNome() +" "+tmp.getCognome());
    		
    	}
    	
    }

}