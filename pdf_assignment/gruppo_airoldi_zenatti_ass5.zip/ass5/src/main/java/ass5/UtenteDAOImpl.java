package ass5;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.*;

public class UtenteDAOImpl implements UtenteDAO {
	
	Connection conn;
	
	public UtenteDAOImpl() {
		conn = null;
	}

	//Restituisce null in caso in cui non esista la coppia user psw
	public Utente get(String username,String password) {
		Utente u= null;
		try {
			conn = ConnectionFactory.getInstance().getConnection();
			
			MessageDigest digest = MessageDigest.getInstance("SHA-1");
			digest.reset();
			digest.update(password.getBytes("utf8"));
			String sha1 = String.format("%040x", new BigInteger(1, digest.digest()));
			
			
			
			String query = "SELECT * FROM Utente WHERE username = ? AND password = ?";
			PreparedStatement preparedStatement = conn.prepareStatement(query); 
			preparedStatement.setString(1, username); 
			preparedStatement.setString(2, sha1); 
			ResultSet rs =preparedStatement.executeQuery();
			 
			while(rs.next())  {
				
				if(rs.getString(5).equalsIgnoreCase("Elettore")) {
					u= new Elettore(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4));
				}else {
					u= new Scrutinatore(rs.getString(1), rs.getString(2), rs.getString(3));
				}
				
			}
				
			conn.close();  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	public List<Utente> getAll() {
		List<Utente> lista = new ArrayList<Utente>();
		try {
			conn = ConnectionFactory.getInstance().getConnection();
			Statement stmt=conn.createStatement();  
			ResultSet rs=stmt.executeQuery("SELECT * FROM Utente");  
			while(rs.next())  {
				Utente u;
				if(rs.getString(5).equalsIgnoreCase("Elettore")) {
					u= new Elettore(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4));
				}else {
					u= new Scrutinatore(rs.getString(1), rs.getString(2), rs.getString(3));
				}
				lista.add(u);
			}
				
				conn.close();  
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return lista;
	}

	public void save(Utente t,String password) {
		
		try {
			conn = ConnectionFactory.getInstance().getConnection();
		
	
			String query = "INSERT INTO Utente(nome,cognome,username,eta,ruolo,password) VALUES(?,?,?,?,?,?);";
			PreparedStatement preparedStatement = conn.prepareStatement(query); 
			preparedStatement.setString(1, t.getNome()); 
			preparedStatement.setString(2, t.getCognome());
			preparedStatement.setString(3, t.getUsername());
			
			MessageDigest digest = MessageDigest.getInstance("SHA-1");
			digest.reset();
			digest.update(password.getBytes("utf8"));
			String sha1 = String.format("%040x", new BigInteger(1, digest.digest()));
			
			if(!t.isScrutinatore()) {
				Elettore tmp = (Elettore) t;
				preparedStatement.setInt(4,tmp.getEta());
				preparedStatement.setString(5,"Elettore");
			}else {
				preparedStatement.setString(5,"Scrutinatore");
			}
			
			preparedStatement.setString(6,sha1);
			
			int row =preparedStatement.executeUpdate();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
			
	}

	public void update(Utente t) {
		String query;
		PreparedStatement preparedStatement=null;
		try {
			conn = ConnectionFactory.getInstance().getConnection();
			if(t.isScrutinatore()) {
				 
				 query = "UPDATE Utente SET nome = ? , cognome = ?  WHERE username = ?;";
				 preparedStatement = conn.prepareStatement(query); 
				 preparedStatement.setString(1, t.getNome()); 
				 preparedStatement.setString(2, t.getCognome()); 
				 preparedStatement.setString(3, t.getUsername()); 
				 
				 
			}else {
				Elettore e =  (Elettore) t;
				 query = "UPDATE Utente SET nome = ? , cognome = ? ,eta=?  WHERE username = ?;";
				 
				 preparedStatement = conn.prepareStatement(query); 
				 preparedStatement.setString(1, e.getNome()); 
				 preparedStatement.setString(2, e.getCognome()); 
				 preparedStatement.setInt(3, e.getEta()); 
				 preparedStatement.setString(4, e.getUsername()); 
			}
			
			
			
			preparedStatement.executeUpdate();
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void delete(Utente t) {
		
			try {
				conn = ConnectionFactory.getInstance().getConnection();
				String query = "DELETE FROM Utente WHERE username = ?";
				PreparedStatement preparedStatement = conn.prepareStatement(query); 
				preparedStatement.setString(1, t.getUsername()); 
				preparedStatement.executeUpdate();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	
			
		
	}

	
	
}
