package ass5;

import java.util.List;

public interface UtenteDAO{
	
	public Utente get(String username,String password);
	    
	public List<Utente> getAll();
	    
	public void save(Utente t,String password);
	    
	public void update(Utente t);
	    
	public void delete(Utente t);
	
}
