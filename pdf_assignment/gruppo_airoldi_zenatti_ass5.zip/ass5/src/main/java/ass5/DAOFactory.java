package ass5;
public class DAOFactory{

	UtenteDAO utenteDao = null;
	
    public static UtenteDAO getUserDAO(){ 
            return new UtenteDAOImpl();
    }
}